<?php
    phpinfo();